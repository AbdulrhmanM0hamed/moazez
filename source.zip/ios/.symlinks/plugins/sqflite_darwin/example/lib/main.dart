import 'package:sqflite_example_common/main.dart';

Future<void> main() async {
  supportsCompatMode = true;
  mainExampleApp();
}
