#import "SqfliteCursor.h"
#import "SqfliteDarwinImport.h"

@implementation SqfliteCursor

@synthesize cursorId;
@synthesize pageSize;
@synthesize resultSet;

@end
